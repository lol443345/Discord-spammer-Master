import discord 
import sys 

client = discord.Client()

@client.event
async def on_ready(): 
    print("The bot is ready!")
    await client.change_presence(activity=discord.Game(name='doing bot stuff')) 

@client.event
async def on_message(message): 
    if message.author == client.user: 
        return
    if message.content == "1": 
        while 1 == 1:
            await message.channel.send("@lol44334567")
    if message.content == "0":
        await client.close()
        sys.exit()


client.run('NzAwNzIxMTExOTE4MzEzNTM0.XpnF6Q.BIoU5TS5h-JUY3l0pyzujnAE7js')